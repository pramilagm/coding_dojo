from django.apps import AppConfig


class AppMyConfig(AppConfig):
    name = 'app_my'

from django.shortcuts import render,redirect
from .models import Order, Product

def index(request):
    if 'total_quantity' not in request.session:
        request.session['total_quantity'] = 0
        request.session['total_charge']  = 0

    context = {
        "all_products": Product.objects.all()
    }
    return render(request, "store/index.html", context)



def checkout(request):
    if request.method =="POST":
        quantity_from_form =int(request.POST["quantity"])
        id_from_form = int(request.POST["product_id"])
        price = Product.objects.get(id=id_from_form).price
        total_charge = quantity_from_form *float(price)
        if 'total_quantity' in request.session:
            request.session['total_quantity'] += quantity_from_form
            request.session['total_charge']  += total_charge
            request.session['recent_charge'] = total_charge
        Order.objects.create(quantity_ordered=quantity_from_form, total_price=total_charge)
        return redirect('/checkout')

    if request.method=="GET":
        context = {
            'total_price' : request.session['total_charge']  ,
            'total_quantity' : request.session['total_quantity'],
            'price': request.session['recent_charge']
        }
        return render(request, "store/checkout.html",context)
    
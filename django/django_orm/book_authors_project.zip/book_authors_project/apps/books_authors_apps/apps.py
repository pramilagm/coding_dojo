from django.apps import AppConfig


class BooksAuthorsAppsConfig(AppConfig):
    name = 'books_authors_apps'
